select
    player_id,
    name_first,
    name_last,
    trim(name_first || ' ' || name_last)                 as player_name,
    nullif(hand, 'U')                                    as hand,
    try_strptime(dob, '%Y%m%d')::date                    as birth_date,
    ioc                                                  as country_code,
    try_cast(height as integer)                          as height_cm
from {{ source('sackmann', 'atp_players') }}
