select
    strptime(ranking_date, '%Y%m%d')::date               as ranking_date,
    player                                               as player_id,
    try_cast(rank as integer)                            as atp_rank,
    try_cast(points as integer)                          as atp_points
from {{ source('sackmann', 'atp_rankings') }}
