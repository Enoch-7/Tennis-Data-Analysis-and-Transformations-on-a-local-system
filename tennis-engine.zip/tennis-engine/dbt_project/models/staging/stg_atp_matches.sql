select
    tourney_id || '-' || match_num                       as match_id,
    tourney_id,
    tourney_name,
    nullif(surface, '')                                  as surface,
    tourney_level,
    strptime(tourney_date, '%Y%m%d')::date               as match_date,
    try_cast(match_num as integer)                       as match_num,
    round,
    case round
        when 'RR' then 0 when 'BR' then 0
        when 'R128' then 1 when 'R64' then 2 when 'R32' then 3 when 'R16' then 4
        when 'QF' then 5 when 'SF' then 6 when 'F' then 7 else 0
    end                                                  as round_order,
    try_cast(best_of as integer)                         as best_of,
    winner_id,
    loser_id,
    winner_name,
    loser_name,
    score,
    try_cast(minutes as integer)                         as minutes,
    try_cast(w_ace as integer)  as w_ace,  try_cast(l_ace as integer)  as l_ace,
    try_cast(w_svpt as integer) as w_svpt, try_cast(l_svpt as integer) as l_svpt,
    try_cast(w_1stIn as integer) as w_1st_in, try_cast(l_1stIn as integer) as l_1st_in,
    try_cast(w_1stWon as integer) as w_1st_won, try_cast(l_1stWon as integer) as l_1st_won
from {{ source('sackmann', 'atp_matches') }}
