-- grain: one row per match
select
    match_id, tourney_id, tourney_name, tourney_level, surface,
    match_date, round, round_order, best_of,
    winner_id, loser_id, score, minutes
from {{ ref('stg_atp_matches') }}
