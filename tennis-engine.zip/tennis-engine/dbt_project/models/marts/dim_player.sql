-- Type-1 for now. Promote to SCD2 (snapshot) once attributes we care about
-- (hand, country) start changing in our sources.
select
    player_id,
    player_name,
    hand,
    birth_date,
    country_code,
    height_cm
from {{ ref('stg_atp_players') }}
