-- grain: player x calendar month. Elo as of the player's last match on/before the
-- month's last ranking snapshot, next to the official ATP ranking at that snapshot.
-- NB: match_date is the tournament START date (Sackmann), so Elo is slightly lagged intra-event.
with snapshots as (
    select
        date_trunc('month', ranking_date)::date          as month,
        player_id,
        max(ranking_date)                                as snapshot_date,
        arg_max(atp_rank, ranking_date)                  as atp_rank,
        arg_max(atp_points, ranking_date)                as atp_points
    from {{ ref('stg_atp_rankings') }}
    group by 1, 2
),

elo_by_date as (
    select
        player_id,
        match_date,
        arg_max(elo_post, seq)                           as elo,
        arg_max(elo_surface_post, seq)                   as elo_surface
    from {{ source('models', 'elo_ratings') }}
    group by 1, 2
),

joined as (
    select
        s.month, s.player_id, s.snapshot_date, s.atp_rank, s.atp_points,
        e.elo, e.match_date as elo_as_of
    from snapshots s
    asof left join elo_by_date e
        on s.player_id = e.player_id and s.snapshot_date >= e.match_date
)

select
    j.*,
    p.player_name,
    rank() over (partition by j.month order by j.elo desc)   as elo_rank,
    j.atp_rank - rank() over (partition by j.month order by j.elo desc) as rank_gap  -- >0: Elo ranks player higher than ATP
from joined j
left join {{ ref('dim_player') }} p using (player_id)
where j.elo is not null
  and j.elo_as_of >= j.snapshot_date - interval 365 day      -- drop long-inactive players
