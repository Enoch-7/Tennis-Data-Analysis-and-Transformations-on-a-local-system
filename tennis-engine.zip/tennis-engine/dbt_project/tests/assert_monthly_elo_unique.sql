select month, player_id, count(*) as n
from {{ ref('mart_monthly_elo_ranking') }}
group by 1, 2
having count(*) > 1
