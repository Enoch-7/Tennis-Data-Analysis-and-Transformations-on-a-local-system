from tennis.ingestion.inbox import archive_file, pending_files


def test_pending_files_only_reads_supported_files_one_level_deep(tmp_path):
    (tmp_path / "pundits").mkdir()
    good = tmp_path / "pundits" / "a.csv"
    good.write_text("x\n1\n")
    (tmp_path / "pundits" / "notes.txt").write_text("ignore")
    (tmp_path / "top_level.csv").write_text("ignored: no table folder")
    assert pending_files(tmp_path) == [good]


def test_archive_moves_file_under_dated_folder(tmp_path):
    src = tmp_path / "inbox" / "pundits" / "a.csv"
    src.parent.mkdir(parents=True)
    src.write_text("x\n1\n")
    dest = archive_file(src, tmp_path / "archive")
    assert dest.exists() and not src.exists()
    assert dest.parent.parent.parent == tmp_path / "archive"
