from datetime import date

import polars as pl
import pytest

from tennis.models.elo import EloConfig, compute_elo, expected


def _matches(rows):
    return pl.DataFrame(
        rows,
        schema={"match_id": pl.Utf8, "match_date": pl.Date, "round_order": pl.Int64,
                "surface": pl.Utf8, "winner_id": pl.Utf8, "loser_id": pl.Utf8},
        orient="row",
    )


def test_expected_is_symmetric():
    assert expected(1500, 1500) == pytest.approx(0.5)
    assert expected(1700, 1500) + expected(1500, 1700) == pytest.approx(1.0)


def test_first_match_uses_start_rating_and_is_zero_sum_for_equal_k():
    df = compute_elo(_matches([("m1", date(2020, 1, 1), 1, "Hard", "A", "B")]))
    a = df.filter(pl.col("player_id") == "A").row(0, named=True)
    b = df.filter(pl.col("player_id") == "B").row(0, named=True)
    assert a["elo_pre"] == b["elo_pre"] == EloConfig().start
    assert a["elo_post"] > a["elo_pre"] > b["elo_post"]
    assert (a["elo_post"] - a["elo_pre"]) == pytest.approx(b["elo_pre"] - b["elo_post"])


def test_pre_match_rating_never_includes_own_result():
    df = compute_elo(_matches([
        ("m1", date(2020, 1, 1), 1, "Clay", "A", "B"),
        ("m2", date(2020, 1, 8), 1, "Clay", "A", "C"),
    ]))
    m1_a = df.filter((pl.col("match_id") == "m1") & (pl.col("player_id") == "A")).row(0, named=True)
    m2_a = df.filter((pl.col("match_id") == "m2") & (pl.col("player_id") == "A")).row(0, named=True)
    assert m2_a["elo_pre"] == pytest.approx(m1_a["elo_post"])  # chained, no leakage


def test_surface_elo_is_independent():
    df = compute_elo(_matches([
        ("m1", date(2020, 1, 1), 1, "Clay", "A", "B"),
        ("m2", date(2020, 1, 8), 1, "Grass", "A", "C"),
    ]))
    m2_a = df.filter((pl.col("match_id") == "m2") & (pl.col("player_id") == "A")).row(0, named=True)
    assert m2_a["elo_surface_pre"] == EloConfig().start  # no grass history yet
    assert m2_a["elo_pre"] > EloConfig().start           # but overall Elo carried over


def test_missing_columns_raise():
    with pytest.raises(ValueError):
        compute_elo(pl.DataFrame({"match_id": ["x"]}))
