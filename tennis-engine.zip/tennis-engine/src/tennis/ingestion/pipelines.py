import dlt

from tennis.common.config import settings
from tennis.ingestion.sackmann import sackmann_source
from tennis.ingestion.tennis_data import tennis_data_source


def _dest():
    return dlt.destinations.duckdb(str(settings.db_path))


def sackmann_pipeline() -> dlt.Pipeline:
    return dlt.pipeline("sackmann", destination=_dest(), dataset_name="raw")


def tennis_data_pipeline() -> dlt.Pipeline:
    return dlt.pipeline("tennis_data", destination=_dest(), dataset_name="raw")


if __name__ == "__main__":
    print(sackmann_pipeline().run(sackmann_source(first_year=settings.first_year)))
    print(tennis_data_pipeline().run(tennis_data_source()))
