"""Jeff Sackmann tennis_atp (CC BY-NC-SA, non-commercial): matches, players, rankings."""
from __future__ import annotations

import urllib.error
from collections.abc import Iterator

import dlt
import polars as pl

BASE = "https://raw.githubusercontent.com/JeffSackmann/tennis_atp/master"
RANKING_FILES = ["atp_rankings_00s", "atp_rankings_10s", "atp_rankings_20s", "atp_rankings_current"]


def _read(url: str) -> pl.DataFrame | None:
    # Everything as string: raw layer stays lossless, dbt staging does the casting.
    try:
        return pl.read_csv(url, infer_schema_length=0, truncate_ragged_lines=True)
    except (urllib.error.HTTPError, pl.exceptions.ComputeError):
        return None  # e.g. current-year file not published yet


@dlt.source(name="sackmann")
def sackmann_source(first_year: int = 2000, last_year: int = 2026):
    @dlt.resource(name="atp_matches", write_disposition="merge",
                  primary_key=("tourney_id", "match_num"))
    def atp_matches() -> Iterator[list[dict]]:
        for year in range(first_year, last_year + 1):
            df = _read(f"{BASE}/atp_matches_{year}.csv")
            if df is not None:
                yield df.to_dicts()

    @dlt.resource(name="atp_players", write_disposition="replace")
    def atp_players() -> Iterator[list[dict]]:
        df = _read(f"{BASE}/atp_players.csv")
        if df is not None:
            yield df.to_dicts()

    @dlt.resource(name="atp_rankings", write_disposition="merge",
                  primary_key=("ranking_date", "player"))
    def atp_rankings() -> Iterator[list[dict]]:
        for name in RANKING_FILES:
            df = _read(f"{BASE}/{name}.csv")
            if df is not None:
                yield df.to_dicts()

    return atp_matches, atp_players, atp_rankings
