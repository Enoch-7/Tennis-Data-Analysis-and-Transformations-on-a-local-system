"""tennis-data.co.uk: results + bookmaker odds, one xlsx per year."""
from __future__ import annotations

import io
import urllib.error
import urllib.request
from collections.abc import Iterator

import dlt
import polars as pl


def _fetch_xlsx(year: int) -> pl.DataFrame | None:
    # Older years are .xls, recent ones .xlsx; try both.
    for ext in ("xlsx", "xls"):
        url = f"http://www.tennis-data.co.uk/{year}/{year}.{ext}"
        try:
            raw = urllib.request.urlopen(url, timeout=60).read()
        except urllib.error.HTTPError:
            continue
        return pl.read_excel(io.BytesIO(raw), engine="calamine", infer_schema_length=0)
    return None


@dlt.source(name="tennis_data")
def tennis_data_source(first_year: int = 2010, last_year: int = 2026):
    @dlt.resource(name="odds_matches", write_disposition="merge",
                  primary_key=("source_year", "Tournament", "Date", "Winner", "Loser", "Round"))
    def odds_matches() -> Iterator[list[dict]]:
        for year in range(first_year, last_year + 1):
            df = _fetch_xlsx(year)
            if df is not None:
                yield df.with_columns(pl.lit(str(year)).alias("source_year")).to_dicts()

    return odds_matches
