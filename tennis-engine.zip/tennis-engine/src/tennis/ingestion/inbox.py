"""Manual ingestion: drop files in data/inbox/<table_name>/ and run the inbox job.

Layout:  data/inbox/pundit_ratings/2026-10-01.csv  ->  raw.pundit_ratings
Supported: .csv .xlsx .json .parquet. Processed files are moved to data/archive/<date>/.
"""
from __future__ import annotations

import shutil
from collections.abc import Iterator
from datetime import date
from pathlib import Path

import dlt
import polars as pl

from tennis.common.config import settings

READERS = {
    ".csv": lambda p: pl.read_csv(p, infer_schema_length=0, truncate_ragged_lines=True),
    ".xlsx": lambda p: pl.read_excel(p, engine="calamine", infer_schema_length=0),
    ".json": lambda p: pl.read_json(p),
    ".parquet": lambda p: pl.read_parquet(p),
}


def pending_files(inbox: Path | None = None) -> list[Path]:
    inbox = inbox or settings.inbox
    return sorted(
        p for p in inbox.glob("*/*") if p.is_file() and p.suffix.lower() in READERS
    )


def archive_file(path: Path, archive: Path | None = None) -> Path:
    dest = (archive or settings.archive) / date.today().isoformat() / path.parent.name
    dest.mkdir(parents=True, exist_ok=True)
    return Path(shutil.move(str(path), dest / path.name))


@dlt.source(name="inbox")
def inbox_source(files: list[Path]):
    tables: dict[str, list[Path]] = {}
    for f in files:
        tables.setdefault(f.parent.name, []).append(f)

    def make(table: str, paths: list[Path]):
        @dlt.resource(name=table, write_disposition="append")
        def _res() -> Iterator[list[dict]]:
            for p in paths:
                df = READERS[p.suffix.lower()](p)
                yield df.with_columns(pl.lit(p.name).alias("_source_file")).to_dicts()
        return _res

    return [make(t, ps) for t, ps in tables.items()]


def run_inbox() -> list[Path]:
    files = pending_files()
    if not files:
        return []
    pipeline = dlt.pipeline("inbox", destination=dlt.destinations.duckdb(str(settings.db_path)),
                            dataset_name="raw")
    pipeline.run(inbox_source(files))
    return [archive_file(f) for f in files]  # only reached if the load succeeded
