from pathlib import Path

from pydantic_settings import BaseSettings, SettingsConfigDict

ROOT = Path(__file__).resolve().parents[3]


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_prefix="TENNIS_", env_file=".env", extra="ignore")

    db_path: Path = ROOT / "data/warehouse/tennis.duckdb"
    data_dir: Path = ROOT / "data"
    first_year: int = 2000

    @property
    def inbox(self) -> Path:
        return self.data_dir / "inbox"

    @property
    def archive(self) -> Path:
        return self.data_dir / "archive"


settings = Settings()
