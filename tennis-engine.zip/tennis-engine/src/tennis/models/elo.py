"""Sequential Elo (overall + per-surface) in Polars.

Elo is path-dependent so it is a single ordered pass, not a set-based query.
Output grain: one row per (match, player) with PRE-match ratings (leakage-safe)
and post-match ratings.

Dynamic K (FiveThirtyEight tennis style): K = OFFSET / (n_matches + SHIFT) ** SHAPE.
"""
from __future__ import annotations

from collections import defaultdict
from dataclasses import dataclass

import polars as pl


@dataclass(frozen=True)
class EloConfig:
    start: float = 1500.0
    k_offset: float = 250.0
    k_shift: float = 5.0
    k_shape: float = 0.4
    surface_weight: float = 0.5  # blend of overall and surface Elo for "elo_blend_pre"


def expected(ra: float, rb: float) -> float:
    return 1.0 / (1.0 + 10 ** ((rb - ra) / 400.0))


def k_factor(n_matches: int, cfg: EloConfig) -> float:
    return cfg.k_offset / (n_matches + cfg.k_shift) ** cfg.k_shape


REQUIRED = ["match_id", "match_date", "round_order", "surface", "winner_id", "loser_id"]


def compute_elo(matches: pl.DataFrame, cfg: EloConfig | None = None) -> pl.DataFrame:
    cfg = cfg or EloConfig()
    missing = [c for c in REQUIRED if c not in matches.columns]
    if missing:
        raise ValueError(f"missing columns: {missing}")

    ordered = matches.sort(["match_date", "round_order", "match_id"])
    overall: dict[str, float] = defaultdict(lambda: cfg.start)
    by_surface: dict[tuple[str, str], float] = defaultdict(lambda: cfg.start)
    played: dict[str, int] = defaultdict(int)

    rows: list[dict] = []
    for seq, m in enumerate(ordered.select(REQUIRED).iter_rows(named=True)):
        w, lo, s = m["winner_id"], m["loser_id"], m["surface"] or "Unknown"
        w_pre, l_pre = overall[w], overall[lo]
        ws_pre, ls_pre = by_surface[(w, s)], by_surface[(lo, s)]
        w_n, l_n = played[w], played[lo]
        kw, kl = k_factor(w_n, cfg), k_factor(l_n, cfg)

        exp_w = expected(w_pre, l_pre)
        exp_ws = expected(ws_pre, ls_pre)
        overall[w] = w_pre + kw * (1 - exp_w)
        overall[lo] = l_pre - kl * (1 - exp_w)
        by_surface[(w, s)] = ws_pre + kw * (1 - exp_ws)
        by_surface[(lo, s)] = ls_pre - kl * (1 - exp_ws)
        played[w] += 1
        played[lo] += 1

        for pid, opp, won, pre, post, spre, spost, n in (
            (w, lo, True, w_pre, overall[w], ws_pre, by_surface[(w, s)], w_n),
            (lo, w, False, l_pre, overall[lo], ls_pre, by_surface[(lo, s)], l_n),
        ):
            rows.append({
                "seq": seq, "match_id": m["match_id"], "match_date": m["match_date"], "surface": s,
                "player_id": pid, "opponent_id": opp, "won": won,
                "elo_pre": pre, "elo_post": post,
                "elo_surface_pre": spre, "elo_surface_post": spost,
                "elo_blend_pre": (1 - cfg.surface_weight) * pre + cfg.surface_weight * spre,
                "matches_played_pre": n,
            })
    return pl.DataFrame(rows, schema_overrides={"match_date": matches.schema["match_date"]})
