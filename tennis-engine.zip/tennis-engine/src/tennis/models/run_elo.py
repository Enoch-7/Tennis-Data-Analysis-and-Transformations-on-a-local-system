"""Read clean matches from DuckDB, compute Elo, write models.elo_ratings back."""
import duckdb

from tennis.common.config import settings
from tennis.models.elo import compute_elo

SQL = """
select match_id, match_date, round_order, surface, winner_id, loser_id
from staging.stg_atp_matches
where winner_id is not null and loser_id is not null and match_date is not null
"""


def run() -> int:
    con = duckdb.connect(str(settings.db_path))
    try:
        matches = con.sql(SQL).pl()
        elo = compute_elo(matches)  # noqa: F841 - read by DuckDB replacement scan below
        con.execute("create schema if not exists models")
        con.execute("create or replace table models.elo_ratings as select * from elo")
        return elo.height
    finally:
        con.close()


if __name__ == "__main__":
    print(f"wrote {run()} rows to models.elo_ratings")
