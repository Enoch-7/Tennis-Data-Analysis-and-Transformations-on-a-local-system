"""Dagster definitions. NOTE: dagster-dlt / dagster-dbt APIs move between releases;
if an import or signature fails after `uv sync`, check the version in uv.lock first.

Graph:  dlt raw -> dbt staging -> Polars Elo -> dbt marts
(dbt is split in two multi-assets so the Elo asset sits between them without a cycle.)
"""
from __future__ import annotations

from pathlib import Path

import dagster as dg
import duckdb
from dagster_dbt import DagsterDbtTranslator, DbtCliResource, DbtProject, dbt_assets
from dagster_dlt import DagsterDltResource, dlt_assets

from tennis.common.config import ROOT, settings
from tennis.ingestion.inbox import pending_files, run_inbox
from tennis.ingestion.pipelines import sackmann_pipeline, tennis_data_pipeline
from tennis.ingestion.sackmann import sackmann_source
from tennis.ingestion.tennis_data import tennis_data_source
from tennis.models.run_elo import run as run_elo

# ---------- raw (dlt) ----------
@dlt_assets(dlt_source=sackmann_source(first_year=settings.first_year),
            dlt_pipeline=sackmann_pipeline(), name="sackmann", group_name="raw")
def sackmann_assets(context: dg.AssetExecutionContext, dlt: DagsterDltResource):
    yield from dlt.run(context=context)


@dlt_assets(dlt_source=tennis_data_source(), dlt_pipeline=tennis_data_pipeline(),
            name="tennis_data", group_name="raw")
def tennis_data_assets(context: dg.AssetExecutionContext, dlt: DagsterDltResource):
    yield from dlt.run(context=context)


@dg.asset(group_name="raw", description="Load files dropped in data/inbox/<table>/ then archive them")
def inbox_files(context: dg.AssetExecutionContext) -> dg.MaterializeResult:
    moved = run_inbox()
    context.log.info(f"archived {len(moved)} files")
    return dg.MaterializeResult(metadata={"files_loaded": len(moved)})


# ---------- dbt ----------
dbt_project = DbtProject(project_dir=ROOT / "dbt_project", profiles_dir=ROOT / "dbt_project")
dbt_project.prepare_if_dev()


class Translator(DagsterDbtTranslator):
    def get_asset_key(self, props):
        if props["resource_type"] == "source":
            if props["source_name"] == "models":  # Polars-produced tables
                return dg.AssetKey(["models", props["name"]])
            return dg.AssetKey(f"dlt_{props['source_name']}_{props['name']}")
        return super().get_asset_key(props)


@dbt_assets(manifest=dbt_project.manifest_path, select="staging",
            dagster_dbt_translator=Translator(), name="dbt_staging")
def dbt_staging(context: dg.AssetExecutionContext, dbt: DbtCliResource):
    yield from dbt.cli(["build"], context=context).stream()


@dbt_assets(manifest=dbt_project.manifest_path, select="marts",
            dagster_dbt_translator=Translator(), name="dbt_marts")
def dbt_marts(context: dg.AssetExecutionContext, dbt: DbtCliResource):
    yield from dbt.cli(["build"], context=context).stream()


# ---------- compute (Polars) ----------
@dg.asset(key=dg.AssetKey(["models", "elo_ratings"]), deps=[dg.AssetKey("stg_atp_matches")],
          group_name="compute", description="Sequential Elo (overall + surface) per player-match")
def elo_ratings() -> dg.MaterializeResult:
    return dg.MaterializeResult(metadata={"rows": run_elo()})


@dg.asset_check(asset=elo_ratings)
def elo_not_empty() -> dg.AssetCheckResult:
    con = duckdb.connect(str(settings.db_path), read_only=True)
    n = con.sql("select count(*) from models.elo_ratings").fetchone()[0]
    con.close()
    return dg.AssetCheckResult(passed=n > 0, metadata={"rows": n})


# ---------- jobs, schedules, sensors ----------
ingest_job = dg.define_asset_job("ingest_job", selection=dg.AssetSelection.groups("raw"))
full_refresh_job = dg.define_asset_job("full_refresh_job", selection=dg.AssetSelection.all())
inbox_job = dg.define_asset_job("inbox_job", selection=dg.AssetSelection.assets(inbox_files))

weekly_ingest = dg.ScheduleDefinition(job=ingest_job, cron_schedule="0 6 * * 1")        # Mon 06:00
monthly_refresh = dg.ScheduleDefinition(job=full_refresh_job, cron_schedule="0 7 1 * *")  # 1st 07:00


@dg.sensor(job=inbox_job, minimum_interval_seconds=60)
def inbox_sensor():
    files = pending_files()
    if files:
        key = "|".join(f"{Path(f).name}:{int(f.stat().st_mtime)}" for f in files)
        yield dg.RunRequest(run_key=key)


defs = dg.Definitions(
    assets=[sackmann_assets, tennis_data_assets, inbox_files, dbt_staging, elo_ratings, dbt_marts],
    asset_checks=[elo_not_empty],
    jobs=[ingest_job, full_refresh_job, inbox_job],
    schedules=[weekly_ingest, monthly_refresh],
    sensors=[inbox_sensor],
    resources={"dlt": DagsterDltResource(), "dbt": DbtCliResource(project_dir=dbt_project)},
)
