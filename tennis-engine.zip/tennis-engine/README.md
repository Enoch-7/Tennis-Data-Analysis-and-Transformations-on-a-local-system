# tennis-engine

Local data pipeline for a tennis betting engine.
`dlt` (ingest) → `DuckDB` (storage) → `dbt` (staging/marts) + `Polars` (Elo) → `Streamlit` (BI), orchestrated by `Dagster`. Environment: `uv`.

## Quick start
    cp .env.example .env
    make setup        # uv sync + git pre-push hook
    make pipeline     # ingest -> dbt staging -> Elo -> dbt marts (no Dagster needed)
    make dashboard    # Streamlit
    make dagster      # UI at http://localhost:3000 (schedules/sensor are off until you enable them)

## Manual ingestion
Drop a file in `data/inbox/<table_name>/` (csv/xlsx/json/parquet). The Dagster `inbox_sensor`
picks it up (or materialize `inbox_files`), loads it to `raw.<table_name>`, then archives it to
`data/archive/<date>/`.

## Layout
- `src/tennis/ingestion` dlt sources · `src/tennis/models` Elo · `src/tennis/orchestration` Dagster
- `dbt_project/` staging → intermediate → marts · `apps/dashboard` Streamlit · `docs/WORKFLOW.md`

## Data licensing
Sackmann datasets are CC BY-NC-SA 4.0 (non-commercial, share-alike). Check every source's terms.
