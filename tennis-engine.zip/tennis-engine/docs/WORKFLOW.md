# Git workflow (Codebase)

- `main` is always runnable. Work on short-lived branches: `feat/<topic>`, `fix/<topic>`.
- Open a **merge request** in Codebase, review, then squash/merge into `main`.
- Commit messages: conventional commits (`feat(elo): add surface blend`). Reference the Codebase
  ticket in the message so commits attach to it (check Codebase's ticket-reference syntax in your
  account's docs).
- Track phases as **Codebase milestones** (Phase 0 … 6) and work items as **tickets**.
- **CI**: Codebase doesn't ship a CI runner. `scripts/ci.sh` is the single check; `make setup`
  installs it as a `pre-push` hook. To get server-side CI later, point a Codebase webhook at
  any runner (self-hosted Woodpecker/Drone, or a mirror to GitHub Actions) and have it run
  `./scripts/ci.sh`.

## Connect the repo
    git remote add origin git@codebasehq.com:<account>/<project>/<repo>.git   # copy exact URL from Codebase
    git push -u origin main
