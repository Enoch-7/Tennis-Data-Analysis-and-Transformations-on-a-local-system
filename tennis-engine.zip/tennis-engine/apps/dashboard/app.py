import duckdb
import plotly.express as px
import streamlit as st

from tennis.common.config import settings

st.set_page_config(page_title="Tennis engine", layout="wide")


@st.cache_data(ttl=300)
def q(sql: str, *params):
    con = duckdb.connect(str(settings.db_path), read_only=True)
    try:
        return con.execute(sql, list(params)).pl()
    finally:
        con.close()


tab_rank, tab_pred = st.tabs(["Monthly Elo vs ATP", "Match predictions"])

with tab_rank:
    months = q("select distinct month from marts.mart_monthly_elo_ranking order by 1 desc")["month"]
    month = st.selectbox("Month", months.to_list())
    top_n = st.slider("Players shown", 10, 200, 50)
    df = q("""select elo_rank, atp_rank, player_name, round(elo) as elo, rank_gap, atp_points
              from marts.mart_monthly_elo_ranking where month = ? order by elo_rank limit ?""",
           month, top_n)
    left, right = st.columns([1, 1])
    left.dataframe(df, use_container_width=True, hide_index=True)
    right.plotly_chart(
        px.scatter(df, x="atp_rank", y="elo", hover_name="player_name",
                   title="Elo vs ATP rank (high Elo / poor rank = potential value)"),
        use_container_width=True)

with tab_pred:
    st.info("Phase 5: model probability vs bookmaker odds, edge, Kelly stake, calibration.")
