#!/usr/bin/env bash
# Single source of truth for checks. Run locally, from the git pre-push hook,
# or from any external CI runner triggered by a Codebase webhook.
set -euo pipefail
cd "$(dirname "$0")/.."

uv sync --frozen 2>/dev/null || uv sync
uv run ruff check .
uv run pytest -q
TENNIS_DB_PATH=/tmp/tennis_ci.duckdb uv run dbt parse --project-dir dbt_project --profiles-dir dbt_project --target ci
echo "CI OK"
