#!/usr/bin/env bash
# Codebase has no built-in CI runner, so gate pushes locally.
set -euo pipefail
cd "$(dirname "$0")/.."
printf '#!/usr/bin/env bash\nexec ./scripts/ci.sh\n' > .git/hooks/pre-push
chmod +x .git/hooks/pre-push scripts/ci.sh
echo "pre-push hook installed"
